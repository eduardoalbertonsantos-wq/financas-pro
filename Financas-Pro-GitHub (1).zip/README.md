# Finanças Pro
Aplicativo financeiro pessoal responsivo.

## Como publicar
Este repositório pode ser publicado pelo GitHub Pages.
Os dados desta primeira versão ficam no navegador (localStorage).
A conexão com Supabase será adicionada na etapa cloud.

## Recursos
Dashboard, entradas, despesas, poupança, metas, análise básica e exportação CSV.
