const KEY="financas_pro_v1";
const money=v=>new Intl.NumberFormat("pt-BR",{style:"currency",currency:"BRL"}).format(Number(v)||0);
const today=()=>new Date().toISOString().slice(0,10);
let db=JSON.parse(localStorage.getItem(KEY)||'{"movements":[],"savings":[],"goals":[],"budget":1200,"debts":0}');
const save=()=>localStorage.setItem(KEY,JSON.stringify(db));
const cats=["Salário","Renda extra","Freelance","Benefício","Reembolso","Venda","Investimento","Moradia","Alimentação","Transporte","Saúde","Academia","Educação","Lazer","Compras","Assinaturas","Contas","Impostos","Dívidas","Outros"];
const $=id=>document.getElementById(id);
$("monthFilter").value=new Date().toISOString().slice(0,7);
function monthData(){let m=$("monthFilter").value;return db.movements.filter(x=>x.date.slice(0,7)===m)}
function render(){
 const arr=monthData(), ins=arr.filter(x=>x.type==="in").reduce((a,x)=>a+x.amount,0), outs=arr.filter(x=>x.type==="out").reduce((a,x)=>a+x.amount,0);
 const sav=db.savings.filter(x=>x.date.slice(0,7)===$("monthFilter").value).reduce((a,x)=>a+x.amount,0);
 $("entradas").textContent=money(ins);$("despesas").textContent=money(outs);$("poupado").textContent=money(sav);$("saldo").textContent=money(ins-outs-sav);
 $("comprometido").textContent=(ins?((outs/ins)*100):0).toFixed(1)+"%";
 const pct=Math.min(100,sav/1200*100);$("saveBar").style.width=pct+"%";$("saveText").textContent=`Meta de poupança: ${money(1200)} • ${pct.toFixed(1)}% atingida`;
 $("goalBar").style.width=pct+"%";$("savingTotal").textContent=money(db.savings.reduce((a,x)=>a+x.amount,0));$("goalPercent").textContent=pct.toFixed(1)+"% da meta atingida";
 $("insight").textContent=outs>ins?"Atenção: suas despesas estão acima das entradas neste mês.":"Seu mês está positivo. Continue controlando os gastos e fortalecendo a poupança.";
 const cat={};arr.filter(x=>x.type==="out").forEach(x=>cat[x.category]=(cat[x.category]||0)+x.amount);
 $("categories").innerHTML=Object.entries(cat).sort((a,b)=>b[1]-a[1]).slice(0,6).map(([k,v])=>`<div class="item"><span>${k}</span><b class="out">${money(v)}</b></div>`).join("")||"<p>Nenhuma despesa registrada.</p>";
 const list=[...arr].sort((a,b)=>b.date.localeCompare(a.date));$("recent").innerHTML=list.slice(0,8).map(itemHTML).join("")||"<p>Nenhum lançamento neste mês.</p>";$("allList").innerHTML=list.map(itemHTML).join("")||"<p>Nenhum lançamento.</p>";
 $("goals").innerHTML=db.goals.map(g=>{let p=Math.min(100,g.target?g.current/g.target*100:0);return `<div class="item"><div><b>${g.name}</b><small>${money(g.current)} de ${money(g.target)}</small><div class="bar" style="margin-top:7px;width:240px"><i style="width:${p}%"></i></div></div><b>${p.toFixed(0)}%</b></div>`}).join("")||"<p>Crie sua primeira meta.</p>";
}
function itemHTML(x){return `<div class="item"><div><b>${x.description}</b><small>${x.date} • ${x.category}</small></div><b class="${x.type}">${x.type==="in"?"+":"-"} ${money(x.amount)}</b></div>`}
function openModal(type){
 $("type").value=type;$("modalTitle").textContent=type==="in"?"Nova entrada":"Nova despesa";$("date").value=today();$("desc").value="";$("amount").value="";$("method").value="";$("note").value="";
 $("category").innerHTML=cats.map(c=>`<option>${c}</option>`).join("");$("modal").classList.remove("hidden");
}
function page(p){document.querySelectorAll(".page").forEach(x=>x.classList.remove("active"));$(""+p).classList.add("active");document.querySelectorAll("nav button").forEach(x=>x.classList.toggle("selected",x.dataset.page===p))}
document.addEventListener("click",e=>{let p=e.target.closest("[data-page]");if(p)page(p.dataset.page)});
$("newEntry").onclick=()=>openModal("in");$("newExpense").onclick=()=>openModal("out");$("addSaving").onclick=()=>{let v=prompt("Valor poupado:");if(v&&Number(v)>0){db.savings.push({date:today(),amount:Number(v)});save();render()}};
$("addGoal").onclick=()=>{let n=prompt("Nome da meta:");if(!n)return;let t=Number(prompt("Valor objetivo:")||0);if(t>0){db.goals.push({name:n,target:t,current:0});save();render()}};
$("closeModal").onclick=()=>$("modal").classList.add("hidden");$("monthFilter").onchange=render;
$("form").onsubmit=e=>{e.preventDefault();db.movements.push({type:$("type").value,date:$("date").value,description:$("desc").value,category:$("category").value,amount:Number($("amount").value),method:$("method").value,note:$("note").value});save();$("modal").classList.add("hidden");render()};
$("clearBtn").onclick=()=>{if(confirm("Apagar todos os dados deste navegador?")){db={movements:[],savings:[],goals:[],budget:1200,debts:0};save();render()}};
$("exportBtn").onclick=()=>{let rows=[["data","tipo","descricao","categoria","valor"],...db.movements.map(x=>[x.date,x.type,x.description,x.category,x.amount])];let csv=rows.map(r=>r.join(";")).join("\\n");let a=document.createElement("a");a.href=URL.createObjectURL(new Blob(["\\ufeff"+csv],{type:"text/csv;charset=utf-8"}));a.download="financas-pro.csv";a.click()};
render();
